from django import forms
from .models import Exercicio, Categoria, Conta, Treino, Avaliacao, Equipamento, Dieta
#criando os formularios do banco de dados
class ExercicioForm(forms.ModelForm):
    class Meta:
        model = Exercicio
        fields = ['nome', 'descricao', 'musculos_trabalhados', 'equipamento', 'nivel_dificuldade']

class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ['nome', 'descricao']

class ContaForm(forms.ModelForm):
    class Meta:
        model = Conta
        fields = ['username', 'email', 'password']

class TreinoForm(forms.ModelForm):
    class Meta:
        model = Treino
        fields = ['usuario', 'exercicio', 'nome', 'descricao', 'duracao', 'data_inicio']

class AvaliacaoForm(forms.ModelForm):
    class Meta:
        model = Avaliacao
        fields = ['usuario', 'exercicio', 'nota', 'comentario', 'data_avaliacao']

class EquipamentoForm(forms.ModelForm):
    class Meta:
        model = Equipamento
        fields = ['nome', 'descricao', 'fabricante']

class DietaForm(forms.ModelForm):
    class Meta:
        model = Dieta
        fields = ['usuario', 'nome', 'descricao', 'calorias_diarias', 'macronutrientes']