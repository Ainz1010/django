from django.apps import AppConfig


class AplicativoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aplicativo'
