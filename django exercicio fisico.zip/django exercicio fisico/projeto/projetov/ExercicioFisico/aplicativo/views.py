from django.shortcuts import render , redirect
from .models import Exercicio , Treino , Conta , Equipamento , Dieta , Categoria , Avaliacao
from .forms import ExercicioForm , TreinoForm , ContaForm , EquipamentoForm , DietaForm , CategoriaForm , AvaliacaoForm
# Create your views here.
def principal(request): #puxando todos os dados para uma pagina principal.
    exercicio = Exercicio.objects.all()
    treino = Treino.objects.all()
    equipamento = Equipamento.objects.all()
    dieta = Dieta.objects.all()
    categoria = Categoria.objects.all()
    avaliacao = Avaliacao.objects.all()
    conta = Conta.objects.all()
    contexto = {
        'exercicio': exercicio,
        'treino': treino,
        'equipamento': equipamento,
        'dieta': dieta,
        'categoria': categoria,
        'avaliacao': avaliacao,
        'conta': conta,
    }
    return render(request, 'aplicativo/principal.html', contexto)

def criar_exercicio(request): #puxando os dados da tabela (model)
    exercicio = Exercicio.objects.all()
    html = 'aplicativo/exercicio.html'
    contexto = {'exercicio':exercicio}
    return render(request,html,contexto )

def exercicio(request):
    if request.method == 'POST':
        form = ExercicioForm(request.POST)
        if form.is_valid():
            form.save()  # Salva os dados do formulário no banco de dados
            # Redireciona para outra página ou exibe uma mensagem de sucesso
            return redirect('/criar')
    else:
        form = ExercicioForm()
    return render(request, 'aplicativo/exercicioform.html', {'form': form})



def treino(request):
    treino = Treino.objects.all()
    html = 'aplicativo/treino.html'
    contexto = {'treino':treino}
    return render(request,html,contexto)

def ftreino(request):
    if request.method == 'POST':
        form = TreinoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/treino')
    else:
        form = TreinoForm()    
    return render(request, 'aplicativo/treinoform.html', {'form': form})

def conta(request):
    conta = Conta.objects.all() 
    html = 'aplicativo/usuario.html'
    contexto = {'conta':conta}
    return render(request,html,contexto)

def fconta(request):
    if request.method == 'POST':
        form = ContaForm(request.POST)
        if form.is_valid():
            form.save() 
            return redirect('/conta')
    else:
        form = ContaForm()
    return render(request, 'aplicativo/fconta.html', {'form': form})


def equipamento(request):
    equipamento = Equipamento.objects.all()
    html = 'aplicativo/equipamento.html'
    contexto = {'equipamento':equipamento}
    return render(request,html,contexto)

def fequipa(request):
    if request.method == 'POST':
        form = EquipamentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/equipamento')
    else:
        form = EquipamentoForm()    
    return render(request, 'aplicativo/fequipa.html', {'form': form})

def dieta(request):
    dieta = Dieta.objects.all()
    html = 'aplicativo/dieta.html'
    contexto = {'dieta':dieta}
    return render(request,html,contexto)

def fdieta(request):
    if request.method == 'POST':
        form = DietaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/dieta')
    else:
        form = DietaForm()    
    return render(request, 'aplicativo/fdieta.html', {'form': form})

def categoria(request):
    categoria = Categoria.objects.all()
    html = 'aplicativo/categoria.html'
    contexto = {'categoria':categoria}
    return render(request,html,contexto)

def fcategoria(request):
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/categoria')
    else:
        form = CategoriaForm()  
    return render(request, 'aplicativo/fcategoria.html', {'form': form})

def avaliacao(request):
    avaliacao = Avaliacao.objects.all()
    html = 'aplicativo/avaliacao.html'
    contexto = {'avaliacao':avaliacao}
    return render(request,html,contexto)

def favaliacao(request):
    if request.method == 'POST':
        form = AvaliacaoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/avaliacao')
    else:                      
        form = AvaliacaoForm()
    return render(request, 'aplicativo/favaliacao.html', {'form': form})



