# exercicio/urls.py
from django.urls import path
from .views import criar_exercicio , treino , conta , equipamento , dieta , categoria , avaliacao , exercicio , ftreino , fconta , fequipa , fdieta , fcategoria , favaliacao , principal

urlpatterns = [
    path('', principal, name='principal'),
    path('criar/', criar_exercicio, name='criar_exercicio'),
    path('formulario', exercicio, name='formulario'),
    path('treino/', treino, name='pagina_treino'),
    path('formtreino/', ftreino, name='cadastra_treino'),
    path('conta/', conta, name='pagina_usuario'),
    path('fconta/', fconta , name='lista_contas'),
    path('equipamento/', equipamento, name='pagina_equipamentos'),
    path('formequipa/', fequipa , name='f_equipamento'),
    path('dieta/', dieta, name='pagina_dieta'),
    path('fdieta/', fdieta, name='f_dieta'),
    path('categoria/', categoria, name='categoria_dos_exercicios'),
    path('fcategoria/', fcategoria, name='f_categoria'),
    path('avaliacao/', avaliacao, name='pagina_avaliacoes'),
    path('favaliacao/', favaliacao, name='f_avaliacao'),
    # Adicione outras URLs aqui, se necessário
]
