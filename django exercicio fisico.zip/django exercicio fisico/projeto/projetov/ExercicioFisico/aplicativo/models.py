from django.db import models
from django.contrib.auth.models import AbstractUser , Group , Permission

#criação das tabelas (model)
class Exercicio(models.Model):
    nome = models.CharField(max_length=100)
    descricao = models.TextField()
    musculos_trabalhados = models.CharField(max_length=100)
    equipamento = models.CharField(max_length=100)
    nivel_dificuldade = models.CharField(max_length=50)

    def __str__(self): #retornar o nome do objeto.
        return self.nome

class Categoria(models.Model):
    nome = models.CharField(max_length=100)
    descricao = models.TextField()

class Conta(AbstractUser):
    email = models.EmailField(unique=True)

    groups = models.ManyToManyField(Group, related_name='usuarios')
    user_permissions = models.ManyToManyField(Permission, related_name='usuarios')
    

class Treino(models.Model):
    usuario = models.ForeignKey(Conta, on_delete=models.CASCADE)
    exercicio = models.ForeignKey(Exercicio, on_delete=models.CASCADE)
    nome = models.CharField(max_length=100)
    descricao = models.TextField()
    duracao = models.CharField(max_length=50)
    data_inicio = models.DateField()

    

class Avaliacao(models.Model):
    usuario = models.ForeignKey(Conta, on_delete=models.CASCADE)
    exercicio = models.ForeignKey(Exercicio, on_delete=models.CASCADE)
    nota = models.IntegerField()
    comentario = models.TextField()
    data_avaliacao = models.DateField()

class Equipamento(models.Model):
    nome = models.CharField(max_length=100)
    descricao = models.TextField()
    fabricante = models.CharField(max_length=100)

class Dieta(models.Model):
    usuario = models.ForeignKey(Conta, on_delete=models.CASCADE)
    nome = models.CharField(max_length=100)
    descricao = models.TextField()
    calorias_diarias = models.IntegerField()
    macronutrientes = models.TextField()